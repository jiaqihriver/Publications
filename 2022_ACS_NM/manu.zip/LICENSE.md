Released under the [LaTeX Project Public
License](http://www.latex-project.org/lppl.txt), v1.3c or later.

The package has status 'maintained': the current maintainer is
[Joseph Wright](joseph.wright@morningstar2.co.uk).

Part of this bundle is derived from `cite.sty`, to which the
following license applies:
  Copyright (C) 1989-2009 by Donald Arseneau
  These macros may be freely transmitted, reproduced, or
  modified provided that this notice is left intact.